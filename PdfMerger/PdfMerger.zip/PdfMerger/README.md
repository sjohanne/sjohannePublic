In this program code(libraries) from apache have been used pdfbox and commons-logging.
I've included the notice from both of these in the NOTICE.txt and in the lib directory once can find two directories one for each with both their LICENSE.txt and their NOTICE.txt.

I'm not the author of either of those two libraries.

This is a simple free to use software to either merge pdf files or to select certain pages from a pdf file.

If there is any problems with the way I've added the LICENSE or NOTICE texts please just mail me and I will fix it as soon as possible.

I hope you will enjoy using this program, I made it simply because I disslike using a online pdf merger with the main reason of the threat of there being malicous code inside.

This program can be used whatever you'r online or offline and it simply works with pdfs.

It cannot handle pdfs which are locked or secure in a way that you cannot open or copy it with the password, it will simply crash.




ATT!
This program requires java. So if you don't have it you can download a 
end-user edition from oracles website it's called JRE, or you can use 
the link below:
https://www.oracle.com/technetwork/java/javase/downloads/jdk11-downloads-5066655.html 

ATT!
Don't move the PdfMerger.jar file make a shortcut/symbolic link to it since the program is dependent on libraries in the folder called lib, and if PdfMerger.jar is moved the program will not work properly.



ATT!
The PdfMergerJar.jar or actually (.PdfMergerJar.jar) a "hidden" file is the original jar file and if by any chance the PdfMerger.jar file is moved or removed or etc you can just copy the .PdfMergerJar.jar file and you'll have a working file again.